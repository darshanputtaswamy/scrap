// ==UserScript==
// @name         My Fancy New Userscript
// @namespace    http://your.homepage/
// @version      0.1
// @description  enter something useful
// @author       You
// @match        https://accounts.google.com/ServiceLogin?service*
// @grant        none
// ==/UserScript==

//window.location.href = 'https://mail.google.com/';
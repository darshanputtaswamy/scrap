// ==UserScript==
// @name         Oracle_SR_Automation_Script_4
// @namespace    http://your.homepage/
// @version      0.1
// @description  Click on the Support Link
// @author       Mandar
// @match        https://support.us.oracle.com/oip/faces/secure/ml3/homepage/home.jspx*
// @grant        none
// @require      http://code.jquery.com/jquery-latest.js
// ==/UserScript==

document.getElementById('_id170:_id172:6:menu').click();
﻿chrome.devtools.panels.create(
    "TheNameOfYourExtension", 
    "icon.png", 
    "index.html",
    function() {
 
    }
)